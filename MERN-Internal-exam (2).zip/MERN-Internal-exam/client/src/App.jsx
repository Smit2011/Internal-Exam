import { useState, useEffect } from 'react'
import './App.css'
import { testAPI } from './services/api'

function App() {
  const [activeTab, setActiveTab] = useState('gallery')
  const [apiMessage, setApiMessage] = useState('')

  useEffect(() => {
    const testConnection = async () => {
      try {
        const data = await testAPI();
        setApiMessage(data.message);
      } catch (error) {
        setApiMessage('Failed to connect to API');
      }
    };
    testConnection();
  }, []);

  return (
    <div className="app">
      <nav className="navbar">
        <div className="nav-brand">ImageVault</div>
        <ul className="nav-links">
          <li 
            className={activeTab === 'gallery' ? 'active' : ''} 
            onClick={() => setActiveTab('gallery')}
          >
            Gallery
          </li>
          <li 
            className={activeTab === 'upload' ? 'active' : ''} 
            onClick={() => setActiveTab('upload')}
          >
            Upload
          </li>
          <li 
            className={activeTab === 'albums' ? 'active' : ''} 
            onClick={() => setActiveTab('albums')}
          >
            Albums
          </li>
        </ul>
      </nav>

      <main className="main-content">
        <div className="content-container">
          {activeTab === 'gallery' && (
            <div className="gallery-section">
              <h1>Your Image Gallery</h1>
              <p>A beautiful space for your memories</p>
              <div className="image-grid">
                {/* Placeholder for demo images */}
                <div className="image-card">
                  <img src="https://source.unsplash.com/400x300?nature" alt="Nature" />
                  <div className="image-overlay">
                    <h3>Nature's Beauty</h3>
                    <p>Captured on: 2024-04-03</p>
                  </div>
                </div>
                <div className="image-card">
                  <img src="https://source.unsplash.com/400x300?city" alt="City" />
                  <div className="image-overlay">
                    <h3>Urban Life</h3>
                    <p>Captured on: 2024-04-03</p>
                  </div>
                </div>
                <div className="image-card">
                  <img src="https://source.unsplash.com/400x300?architecture" alt="Architecture" />
                  <div className="image-overlay">
                    <h3>Modern Architecture</h3>
                    <p>Captured on: 2024-04-03</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'upload' && (
            <div className="upload-section">
              <h2>Upload Images</h2>
              <div className="upload-area">
                <div className="upload-box">
                  <i className="upload-icon">📁</i>
                  <p>Drag and drop your images here</p>
                  <p>or</p>
                  <button className="upload-button">Choose Files</button>
                </div>
                <div className="upload-info">
                  <p>Supported formats: JPG, PNG, GIF</p>
                  <p>Maximum file size: 5MB</p>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'albums' && (
            <div className="albums-section">
              <h2>Your Albums</h2>
              <div className="albums-grid">
                <div className="album-card">
                  <img src="https://source.unsplash.com/400x300?vacation" alt="Vacation Album" />
                  <h3>Vacation 2024</h3>
                  <p>15 photos</p>
                </div>
                <div className="album-card">
                  <img src="https://source.unsplash.com/400x300?family" alt="Family Album" />
                  <h3>Family</h3>
                  <p>32 photos</p>
                </div>
                <div className="album-card">
                  <img src="https://source.unsplash.com/400x300?events" alt="Events Album" />
                  <h3>Events</h3>
                  <p>24 photos</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

export default App
